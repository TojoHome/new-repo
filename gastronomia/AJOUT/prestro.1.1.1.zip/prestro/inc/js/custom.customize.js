jQuery(document).ready(function(e) {
    jQuery('.accordion-section-title').eq(1).after('<a style="position:relative;left:15px;padding:4px 10px;bottom:35px;background:#007cb5;color:#fff;margin-bottom:30px;" href="http://themesware.com/product/presto" target="_blank">Upgrade to PRO Version</a>');
	jQuery('.accordion-section-title').eq(1).css('padding-bottom','35px');
});